---
name: Suggest a digital holography resource
about: Suggest a paper, code, dataset, hardware, or tutorial
---

**Resource name / 资源名称：**

**Official URL / 官方链接：**

**Type / 论文、代码、数据、硬件、教程：**

**Holography geometry / 同轴、离轴、无物镜、双相机：**

**Direct relevance to imaging/measurement / 与数字全息成像测量的直接关系：**

**Raw holograms and per-particle independent GT? / 原始图与独立真值：**

**License, model weights and reproducibility notes / 许可、权重和复现条件：**
